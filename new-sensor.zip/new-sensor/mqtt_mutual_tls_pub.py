import paho.mqtt.client as mqtt
import ssl
import time
import RPi.GPIO as GPIO

# -----------------------
# MQTT CONFIG
# -----------------------
BROKER = "10.233.114.136"
PORT   = 8883
TOPIC  = "mutual/test"

client = mqtt.Client(client_id="ultrasonic_publisher")

client.tls_set(
    ca_certs="ca.crt",
    certfile="client.crt",
    keyfile="client.key",
    tls_version=ssl.PROTOCOL_TLSv1_2
)
client.tls_insecure_set(True)   # Only for testing!

def on_connect(client, userdata, flags, rc):
    print(f"[MQTT] Connected: {mqtt.error_string(rc)}")

def on_publish(client, userdata, mid):
    print(f"[MQTT] Published MID={mid}")

client.on_connect = on_connect
client.on_publish = on_publish

# -----------------------
# ULTRASONIC SENSOR CONFIG
# -----------------------
TRIG = 17
ECHO = 27

GPIO.setmode(GPIO.BCM)
GPIO.setup(TRIG, GPIO.OUT)
GPIO.setup(ECHO, GPIO.IN)

def get_distance():
    """Return distance in cm or None if invalid."""
    GPIO.output(TRIG, False)
    time.sleep(0.05)

    # Trigger pulse
    GPIO.output(TRIG, True)
    time.sleep(0.00001)
    GPIO.output(TRIG, False)

    # ----------------------
    # Wait for echo HIGH
    # ----------------------
    timeout = time.time() + 0.02  # 20ms max wait
    while GPIO.input(ECHO) == 0:
        pulse_start = time.time()
        if time.time() > timeout:
            return None   # No echo received

    # ----------------------
    # Wait for echo LOW
    # ----------------------
    timeout = time.time() + 0.02
    while GPIO.input(ECHO) == 1:
        pulse_end = time.time()
        if time.time() > timeout:
            return None   # Echo too long/unrealistic

    pulse_duration = pulse_end - pulse_start
    distance_cm = pulse_duration * 17150
    return round(distance_cm, 2)

# -----------------------
# MAIN LOOP
# -----------------------
print("[MQTT] Connecting to broker…")
client.connect(BROKER, PORT, keepalive=60)
client.loop_start()

try:
    while True:
        distance = get_distance()

        if distance is None:
            print("[WARN] Invalid reading (timeout, no echo).")
            time.sleep(1)
            continue

        print(f"[SENSOR] Distance: {distance} cm")
        client.publish(TOPIC, str(distance))

        time.sleep(1)

except KeyboardInterrupt:
    print("Stopping…")

finally:
    client.loop_stop()
    GPIO.cleanup()

